import React, { useEffect, useState } from 'react';
import Modal from 'react-modal';
import { fetchUsers, createUser, updateUser, deleteUser } from '../api/usersApi';
import styles from './Users.module.css'; // Ensure this is the correct path

interface User {
    id: string;
    name: string;
    email: string;
}

const Users: React.FC = () => {
    const [users, setUsers] = useState<User[]>([]);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);
    const [formState, setFormState] = useState<{ id: string; name: string; email: string }>({ id: '', name: '', email: '' });
    const [modalIsOpen, setModalIsOpen] = useState(false);
    const [modalType, setModalType] = useState<'create' | 'update' | 'delete' | null>(null);
    const [userToDelete, setUserToDelete] = useState<string | null>(null);
    const [editingUserId, setEditingUserId] = useState<string | null>(null);

    const getUsers = async () => {
        try {
            const data = await fetchUsers();
            setUsers(data);
        } catch (error) {
            setError('Failed to fetch users');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        getUsers();
    }, []);

    const handleCreateUser = async () => {
        try {
            const user = await createUser(formState);
            setUsers([...users, user]);
            setFormState({ id: '', name: '', email: '' });
            setError(null);
            setModalIsOpen(false); // Close modal on success
        } catch (error) {
            setError('Failed to create user');
        }
    };

    const handleUpdateUser = async () => {
        if (!editingUserId) return;
        try {
            await updateUser(editingUserId, { name: formState.name, email: formState.email });
            await getUsers(); // Fetch the updated list of users
            setFormState({ id: '', name: '', email: '' });
            setEditingUserId(null);
            setError(null);
            setModalIsOpen(false); // Close modal on success
        } catch (error) {
            setError('Failed to update user');
        }
    };

    const handleDeleteUser = async () => {
        if (!userToDelete) return;
        try {
            await deleteUser(userToDelete);
            setUsers(users.filter(user => user.id !== userToDelete));
            setUserToDelete(null);
            setError(null);
            setModalIsOpen(false); // Close modal on success
        } catch (error) {
            setError('Failed to delete user');
        }
    };

    const handleEditUser = (user: User) => {
        setFormState({ id: user.id, name: user.name, email: user.email });
        setEditingUserId(user.id);
        setModalType('update');
        setModalIsOpen(true);
    };

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormState(prevState => ({ ...prevState, [name]: value }));
    };

    const handleCancelEdit = () => {
        setFormState({ id: '', name: '', email: '' });
        setEditingUserId(null);
        setModalIsOpen(false); // Close modal
    };

    if (loading) {
        return <div>Loading users...</div>;
    }

    if (error) {
        return <div>Error: {error}</div>;
    }

    return (
        <div style={{ padding: '2rem' }}>
            <h1>Users</h1>
            <ul>
                {users.map(user => (
                    <li key={user.id}>
                        <strong>ID:</strong> {user.id} <br />
                        <strong>Name:</strong> {user.name} <br />
                        <strong>Email:</strong> {user.email} <br />
                        <button onClick={() => handleEditUser(user)}>Update</button>
                        <button onClick={() => { setUserToDelete(user.id); setModalType('delete'); setModalIsOpen(true); }}>Delete</button>
                    </li>
                ))}
            </ul>
            <button onClick={() => { setModalType('create'); setModalIsOpen(true); }}>Create New User</button>

            <Modal isOpen={modalIsOpen} onRequestClose={() => setModalIsOpen(false)} className={styles.modal} overlayClassName={styles.overlay}>
                {modalType === 'delete' && userToDelete && (
                    <div>
                        <div className={styles.modalHeader}>Are you sure you want to delete this user?</div>
                        <div className={styles.modalFooter}>
                            <button className={`${styles.primary} ${styles.modalButton}`} onClick={handleDeleteUser}>Delete</button>
                            <button className={`${styles.secondary} ${styles.modalButton}`} onClick={() => setModalIsOpen(false)}>Cancel</button>
                        </div>
                    </div>
                )}
                {(modalType === 'create' || modalType === 'update') && (
                    <div>
                        <div className={styles.modalHeader}>{modalType === 'create' ? 'Create New User' : 'Update User'}</div>
                        <div className={styles.modalContent}>
                            <div className={styles.inputGroup}>
                                <label>ID</label>
                                <input
                                    type="text"
                                    name="id"
                                    placeholder="ID"
                                    value={formState.id}
                                    onChange={handleInputChange}
                                    disabled={!!editingUserId} // Disable ID field when editing
                                />
                            </div>
                            <div className={styles.inputGroup}>
                                <label>Name</label>
                                <input
                                    type="text"
                                    name="name"
                                    placeholder="Name"
                                    value={formState.name}
                                    onChange={handleInputChange}
                                />
                            </div>
                            <div className={styles.inputGroup}>
                                <label>Email</label>
                                <input
                                    type="email"
                                    name="email"
                                    placeholder="Email"
                                    value={formState.email}
                                    onChange={handleInputChange}
                                />
                            </div>
                        </div>
                        <div className={styles.modalFooter}>
                            <button className={`${styles.primary} ${styles.modalButton}`} onClick={modalType === 'create' ? handleCreateUser : handleUpdateUser}>
                                {modalType === 'create' ? 'Create' : 'Update'}
                            </button>
                            <button className={`${styles.secondary} ${styles.modalButton}`} onClick={handleCancelEdit}>Cancel</button>
                        </div>
                    </div>
                )}
            </Modal>
        </div>
    );
};

export default Users;