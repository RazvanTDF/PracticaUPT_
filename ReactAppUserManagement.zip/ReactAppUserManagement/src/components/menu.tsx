import React from 'react';
import './menu.css';

const Menu: React.FC = () => {
    return (
        <nav className="menu">
        </nav>
    );
};

export default Menu;