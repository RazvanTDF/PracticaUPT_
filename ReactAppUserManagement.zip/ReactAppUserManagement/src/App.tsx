import React from 'react';
import Menu from './components/menu';
import Users from './components/Users';

const App: React.FC = () => {
  return (
      <div>
        <Menu />
        <Users />
      </div>
  );
};

export default App;